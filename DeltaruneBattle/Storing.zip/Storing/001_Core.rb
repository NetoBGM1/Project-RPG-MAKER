#===============================================================================
# Deltarune Battle
# Core
# Pokémon Essentials v21.1
#===============================================================================

module DeltaruneBattle
  @active = false
  @turn = 1

  def self.active
    return @active
  end

  def self.turn
    return @turn
  end

  #---------------------------------------------------------------------------
  # Reset turn counter
  #---------------------------------------------------------------------------

  def self.reset_turn
    @turn = 1
  end

  #---------------------------------------------------------------------------
  # Advance turn
  #---------------------------------------------------------------------------

  def self.next_turn
    @turn += 1
  end

  #---------------------------------------------------------------------------
  # Start
  #---------------------------------------------------------------------------

  def self.start
    return false if @active

    @active = true
    reset_turn

    begin
      scene = DeltaruneBattle::Scene.new

      # For now this only starts our custom scene.
      # The actual Essentials battle connection will be added after
      # the scene itself is confirmed working.

      scene.start_test

      return true
    rescue Exception => e
      raise e
    ensure
      @active = false
    end
  end
end


#===============================================================================
# Event Script
#===============================================================================

def pbDeltaruneBattle
  DeltaruneBattle.start
end


#===============================================================================
# Deltarune Battle - Wild Battle
#===============================================================================

def pbDeltaruneWildBattle(species, level)
  pokemon = Pokemon.new(species, level)

  party = $player.party

  if party.nil? || party.empty?
    pbMessage(_INTL("You don't have any Pokémon!"))
    return false
  end

  # Create our custom battle scene.
  scene = DeltaruneBattle::Scene.new

  # Create a wild battle.
  battle = Battle.new(
    scene,
    party,
    [pokemon],
    $player,
    nil
  )

  # This is an internal battle, just like a normal Pokémon battle.
  battle.internalBattle = true

  # Start the actual Essentials battle.
  decision = battle.pbStartBattle

  return decision
end
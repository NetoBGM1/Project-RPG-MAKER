#===============================================================================
# Deltarune Battle
# UI
#===============================================================================

module DeltaruneBattle
  class CommandSelector

    attr_reader :index

    def initialize(scene)
      @scene = scene
      @index = 0
    end

    def update
      if Input.trigger?(Input::LEFT)
        move(-1)
      elsif Input.trigger?(Input::RIGHT)
        move(1)
      elsif Input.trigger?(Input::UP)
        move(-2)
      elsif Input.trigger?(Input::DOWN)
        move(2)
      elsif Input.trigger?(Input::USE)
        return choose
      elsif Input.trigger?(Input::BACK)
        return :cancel
      end

      return nil
    end

    def move(amount)
      @index += amount

      @index = 0 if @index < 0
      @index = 3 if @index > 3

      refresh
    end

    def refresh
      @scene.pbRefreshCommandBox(@index)
    end

    def choose
      return DeltaruneBattle::COMMANDS[@index]
    end
  end
end


#===============================================================================
# Scene UI methods
#===============================================================================

class DeltaruneBattle::Scene

  def pbCreateCommandSelector
    @commandSelector = DeltaruneBattle::CommandSelector.new(self)
    @commandSelector.refresh
  end

  def pbRefreshCommandBox(index)
    sprite = @sprites["command_box"]
    return if !sprite || sprite.disposed?

    # Temporary positioning.
    #
    # This will be replaced once the actual Deltarune command graphic
    # is integrated.

    positions = [
      [30, 402],   # FIGHT
      [190, 402],  # BAG
      [350, 402],  # POKEMON
      [510, 402]   # RUN
    ]

    sprite.x = positions[index][0]
    sprite.y = positions[index][1]
  end

  def pbDeltaruneCommandMenu
    pbCreateCommandSelector

    loop do
      Graphics.update
      Input.update

      result = @commandSelector.update

      next if result.nil?

      case result
      when :fight
        pbDeltaruneMessage(_INTL("Choose a move."))
        return :fight

      when :bag
        pbDeltaruneMessage(_INTL("You opened the Bag."))
        return :bag

      when :pokemon
        pbDeltaruneMessage(_INTL("Choose a Pokémon."))
        return :pokemon

      when :run
        pbDeltaruneMessage(_INTL("You tried to run away."))
        return :run

      when :cancel
        return :cancel
      end
    end
  end
end
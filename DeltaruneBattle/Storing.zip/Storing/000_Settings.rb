#===============================================================================
# Deltarune Battle
# Settings
# Pokémon Essentials v21.1
#===============================================================================

module DeltaruneBattle
  #---------------------------------------------------------------------------
  # General
  #---------------------------------------------------------------------------

  SCREEN_WIDTH  = 640
  SCREEN_HEIGHT = 480

  #---------------------------------------------------------------------------
  # Graphics
  #---------------------------------------------------------------------------

  UI_PATH = "Graphics/DeltaruneBattle/UI/"

  HUD_GRAPHIC          = UI_PATH + "HUD"
  BATTLE_MENU_GRAPHIC  = UI_PATH + "BattleMenu"
  TEXTBOX_GRAPHIC      = UI_PATH + "textbox"
  COMMAND_BOX_GRAPHIC  = UI_PATH + "command_box"

  #---------------------------------------------------------------------------
  # UI positions
  #---------------------------------------------------------------------------

  # Turn counter
  TURN_X = 280
  TURN_Y = 12

  # HUDs
  PLAYER_HUD_X = 16
  PLAYER_HUD_Y = 300

  ENEMY_HUD_X = 384
  ENEMY_HUD_Y = 32

  # Main command menu
  MENU_X = 16
  MENU_Y = 394

  # Text box
  TEXTBOX_X = 16
  TEXTBOX_Y = 324

  # Command cursor
  COMMAND_X = MENU_X
  COMMAND_Y = MENU_Y

  #---------------------------------------------------------------------------
  # Trainer positions
  #---------------------------------------------------------------------------

  PLAYER_TRAINER_X = 120
  PLAYER_TRAINER_Y = 285

  ENEMY_TRAINER_X = 520
  ENEMY_TRAINER_Y = 165

  #---------------------------------------------------------------------------
  # Pokémon positions
  #---------------------------------------------------------------------------

  PLAYER_POKEMON_X = 190
  PLAYER_POKEMON_Y = 285

  ENEMY_POKEMON_X = 440
  ENEMY_POKEMON_Y = 165

  #---------------------------------------------------------------------------
  # Commands
  #---------------------------------------------------------------------------

  COMMANDS = [
    :fight,
    :bag,
    :pokemon,
    :run
  ]

  COMMAND_NAMES = {
    :fight   => "FIGHT",
    :bag     => "BAG",
    :pokemon => "POKEMON",
    :run     => "RUN"
  }
end
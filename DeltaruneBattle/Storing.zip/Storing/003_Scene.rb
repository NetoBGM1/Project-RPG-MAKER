#===============================================================================
# Deltarune Battle
# Test Scene
# Pokémon Essentials v21.1
#===============================================================================

module DeltaruneBattle
  class Scene

    def initialize
      @viewport = nil
      @sprites = {}
    end

    #---------------------------------------------------------------------------
    # Start test
    #---------------------------------------------------------------------------

    def start_test
      create_viewport
      create_background
      create_ui

      refresh_turn

      loop do
        Graphics.update
        Input.update

        break if Input.trigger?(Input::BACK)

        update_input
      end

      dispose
    end

    #---------------------------------------------------------------------------
    # Viewport
    #---------------------------------------------------------------------------

    def create_viewport
      @viewport = Viewport.new(
        0,
        0,
        Graphics.width,
        Graphics.height
      )

      @viewport.z = 99999
    end

    #---------------------------------------------------------------------------
    # Background
    #---------------------------------------------------------------------------

    def create_background
      sprite = Sprite.new(@viewport)

      sprite.bitmap = Bitmap.new(
        Graphics.width,
        Graphics.height
      )

      sprite.bitmap.fill_rect(
        0,
        0,
        Graphics.width,
        Graphics.height,
        Color.new(25, 25, 30)
      )

      sprite.z = 0

      @sprites["background"] = sprite
    end

    #---------------------------------------------------------------------------
    # UI
    #---------------------------------------------------------------------------

    def create_ui
      create_turn
      create_battle_menu
      create_command_box
      create_textbox
    end

    #---------------------------------------------------------------------------
    # Turn
    #---------------------------------------------------------------------------

    def create_turn
      sprite = Sprite.new(@viewport)

      sprite.bitmap = Bitmap.new(120, 32)

      sprite.x = DeltaruneBattle::TURN_X
      sprite.y = DeltaruneBattle::TURN_Y

      sprite.z = 100

      @sprites["turn"] = sprite
    end

    def refresh_turn
      sprite = @sprites["turn"]
      return if !sprite

      sprite.bitmap.clear

      pbSetSystemFont(sprite.bitmap)

      sprite.bitmap.draw_text(
        0,
        0,
        120,
        32,
        _INTL("TURN {1}", DeltaruneBattle.turn),
        1
      )
    end

    #---------------------------------------------------------------------------
    # Battle Menu
    #---------------------------------------------------------------------------

    def create_battle_menu
      sprite = Sprite.new(@viewport)

      begin
        sprite.bitmap = Bitmap.new(
          DeltaruneBattle::BATTLE_MENU_GRAPHIC
        )
      rescue
        sprite.bitmap = Bitmap.new(
          608,
          70
        )

        sprite.bitmap.fill_rect(
          0,
          0,
          608,
          70,
          Color.new(10, 10, 15)
        )
      end

      sprite.x = DeltaruneBattle::MENU_X
      sprite.y = DeltaruneBattle::MENU_Y

      sprite.z = 50

      @sprites["battle_menu"] = sprite
    end

    #---------------------------------------------------------------------------
    # Command Box
    #---------------------------------------------------------------------------

    def create_command_box
      sprite = Sprite.new(@viewport)

      begin
        sprite.bitmap = Bitmap.new(
          DeltaruneBattle::COMMAND_BOX_GRAPHIC
        )
      rescue
        sprite.bitmap = Bitmap.new(120, 40)

        sprite.bitmap.fill_rect(
          0,
          0,
          120,
          40,
          Color.new(255, 255, 255)
        )
      end

      sprite.x = DeltaruneBattle::COMMAND_X
      sprite.y = DeltaruneBattle::COMMAND_Y

      sprite.z = 100

      @sprites["command_box"] = sprite
    end

    #---------------------------------------------------------------------------
    # Textbox
    #---------------------------------------------------------------------------

    def create_textbox
      sprite = Sprite.new(@viewport)

      begin
        sprite.bitmap = Bitmap.new(
          DeltaruneBattle::TEXTBOX_GRAPHIC
        )
      rescue
        sprite.bitmap = Bitmap.new(
          608,
          64
        )

        sprite.bitmap.fill_rect(
          0,
          0,
          608,
          64,
          Color.new(10, 10, 15)
        )
      end

      sprite.x = DeltaruneBattle::TEXTBOX_X
      sprite.y = DeltaruneBattle::TEXTBOX_Y

      sprite.z = 25

      @sprites["textbox"] = sprite
    end

    #---------------------------------------------------------------------------
    # Input
    #---------------------------------------------------------------------------

    def update_input
      if Input.trigger?(Input::USE)
        DeltaruneBattle.next_turn
        refresh_turn
      end
    end

    #---------------------------------------------------------------------------
    # Dispose
    #---------------------------------------------------------------------------

    def dispose
      @sprites.each_value do |sprite|
        sprite.dispose if sprite && !sprite.disposed?
      end

      @sprites.clear

      if @viewport && !@viewport.disposed?
        @viewport.dispose
      end

      @viewport = nil
    end
  end
end